"""
Agent Card utilities for A2A discovery and capability exposure.

Provides helpers for generating Agent Cards according to the A2A protocol specification.
All cards now use a2a.types.AgentCard for proper A2A compatibility.
"""

import logging
from typing import List, Any, Optional

logger = logging.getLogger(__name__)


def create_planner_agent_card() -> 'AgentCard':
    """
    Create the Agent Card for the Planner Agent.
    
    Returns:
        a2a.types.AgentCard configured for event planning capabilities
    """
    from a2a.types import AgentCard, AgentSkill, AgentCapabilities
    
    return AgentCard(
        name="Planner Agent",
        description="Specialized agent for creating fun, personalized event plans with venues and activities",
        version="1.0.0",
        url="",  # Will be set by A2aAgent deployment
        preferred_transport="HTTP+JSON",  # Required by A2aAgent
        skills=[
            AgentSkill(
                id="create_event_plan",
                name="Event Plan Generator",
                description="Creates detailed event plans with specific venues, addresses, coordinates, and invite messages",
                tags=["planning", "events", "social", "venues"],
                examples=[
                    "Plan a birthday celebration in Seattle for 5 friends",
                    "Create a fun night out in Boston with dinner and entertainment",
                    "Design a weekend activity plan for a group in San Francisco"
                ]
            )
        ],
        capabilities=AgentCapabilities(
            streaming=False,
            pushNotifications=False,
            stateTransitionHistory=False
        ),
        default_input_modes=["text"],
        default_output_modes=["text"]
    )


def create_social_agent_card() -> 'AgentCard':
    """
    Create the Agent Card for the Social Agent.
    
    Returns:
        a2a.types.AgentCard configured for social profile analysis
    """
    from a2a.types import AgentCard, AgentSkill, AgentCapabilities
    
    return AgentCard(
        name="Social Agent",
        description="Analyzes social profiles, posts, friendships, and event attendance",
        version="1.0.0",
        url="",  # Will be set by A2aAgent deployment
        preferred_transport="HTTP+JSON",  # Required by A2aAgent
        skills=[
            AgentSkill(
                id="analyze_social_profile",
                name="Social Profile Analyzer",
                description="Retrieves and summarizes a person's social activity including posts, friends, and attended events",
                tags=["social", "profile", "analysis", "friends"],
                examples=[
                    "Get Sarah's social profile and recent activity",
                    "Summarize John's friends and event history"
                ]
            )
        ],
        capabilities=AgentCapabilities(
            streaming=False,
            pushNotifications=False,
            stateTransitionHistory=False
        ),
        default_input_modes=["text"],
        default_output_modes=["text"]
    )


def create_platform_agent_card(mcp_tools: Optional[List[Any]] = None) -> 'AgentCard':
    """
    Create the Agent Card for the Platform MCP Client Agent.
    
    This card is dynamic - it describes the capabilities based on
    the MCP tools that are currently loaded.
    
    Args:
        mcp_tools: List of MCP tools currently available
        
    Returns:
        a2a.types.AgentCard with skills based on available MCP tools
    """
    from a2a.types import AgentCard, AgentSkill, AgentCapabilities
    
    skills = []
    
    if mcp_tools:
        # Generate skills from MCP tool metadata
        for tool in mcp_tools:
            skill = AgentSkill(
                id=f"mcp_{tool.name}",
                name=tool.name.replace('_', ' ').title(),
                description=getattr(tool, 'description', f"Execute {tool.name} via MCP"),
                tags=["platform", "mcp", "backend"],
                examples=[]
            )
            skills.append(skill)
    else:
        # Default skill if no tools loaded yet
        skills.append(
            AgentSkill(
                id="platform_operations",
                name="Platform Operations",
                description="Execute backend operations via MCP tool server",
                tags=["platform", "mcp", "backend"],
                examples=["Create an event", "Update user profile"]
            )
        )
    
    return AgentCard(
        name="Platform MCP Client Agent",
        description="Executes backend platform operations via Model Context Protocol (MCP) tools",
        version="1.0.0",
        url="",  # Will be set by A2aAgent deployment
        preferred_transport="HTTP+JSON",  # Required by A2aAgent
        skills=skills,
        capabilities=AgentCapabilities(
            streaming=False,
            pushNotifications=False,
            stateTransitionHistory=False
        ),
        default_input_modes=["text"],
        default_output_modes=["text"]
    )
