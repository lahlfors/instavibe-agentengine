
"""
Agent Card definitions for remote agents used by the Orchestrate Agent.
Follows the design pattern of constructing AgentCard objects directly.
"""

from a2a.types import AgentCard, AgentSkill, AgentCapabilities
from .schemas import PlannerInput, PlannerOutput, SocialInput, SocialOutput, PlatformInput, PlatformOutput

def create_planner_card(base_url: str) -> AgentCard:
    """Creates the AgentCard for the Planner Agent."""
    # A2A client appends /v1/message:send to the card URL
    # So we need to provide base_url/a2a, not just base_url
    a2a_url = f"{base_url}/a2a"
    
    return AgentCard(
        name="PlannerAgent",
        description="Generates detailed event plans with venues and activities",
        url=a2a_url,
        version="1.0.0",
        preferred_transport="HTTP+JSON",
        skills=[
            AgentSkill(
                id="plan_event",
                name="Plan Event",
                description="Create a personalized event plan",
                input_schema=PlannerInput.model_json_schema(),
                output_schema=PlannerOutput.model_json_schema(),
                tags=["planning", "events", "venues"]
            )
        ],
        default_input_modes=["application/json"],
        default_output_modes=["application/json"],
        capabilities=AgentCapabilities(streaming=False)
    )

def create_social_card(base_url: str) -> AgentCard:
    """Creates the AgentCard for the Social Agent."""
    # A2A client appends /v1/message:send to the card URL
    # So we need to provide base_url/a2a, not just base_url
    a2a_url = f"{base_url}/a2a"
    
    return AgentCard(
        name="SocialAgent",
        description="Analyzes social profiles, posts, friendships, and event attendance",
        url=a2a_url,
        version="1.0.0",
        preferred_transport="HTTP+JSON",
        skills=[
            AgentSkill(
                id="get_profile",
                name="Get Profile",
                description="Get user profile and interests",
                input_schema=SocialInput.model_json_schema(),
                output_schema=SocialOutput.model_json_schema(),
                tags=["social", "profile"]
            )
        ],
        default_input_modes=["application/json"],
        default_output_modes=["application/json"],
        capabilities=AgentCapabilities(streaming=False)
    )

def create_platform_card(base_url: str) -> AgentCard:
    """Creates the AgentCard for the Platform MCP Client Agent."""
    # A2A client appends /v1/message:send to the card URL
    # So we need to provide base_url/a2a, not just base_url
    a2a_url = f"{base_url}/a2a"
    
    return AgentCard(
        name="PlatformMCPClientAgent",
        description="Provides access to platform tools and services via MCP",
        url=a2a_url,
        version="1.0.0",
        preferred_transport="HTTP+JSON",
        skills=[
            AgentSkill(
                id="query_tools",
                name="Query Platform Tools",
                description="Execute queries against platform tools",
                input_schema=PlatformInput.model_json_schema(),
                output_schema=PlatformOutput.model_json_schema(),
                tags=["platform", "tools", "mcp"]
            )
        ],
        default_input_modes=["application/json"],
        default_output_modes=["application/json"],
        capabilities=AgentCapabilities(streaming=False)
    )
